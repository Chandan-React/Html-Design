// Selector
const todoInput = document.querySelector('.todoInput'),
      todoButton = document.querySelector('.todoButton'),
      todoList = document.querySelector('.todoList'),
      filterOption = document.querySelector('.filter-todo');

// Event Listener
// Button Clicked
todoButton.addEventListener('click', addToDo);
todoList.addEventListener('click', deleteCheck);
filterOption.addEventListener('click', filterTodo);


// Functions

function addToDo(e){
    e.preventDefault();
    const val = todoInput.value;
    if(val === ''){
        alert("Please Add Items");
    }else{
        const todoDiv = document.createElement("div");
        todoDiv.classList.add("todo");

        // Create Li
        const newTodo = document.createElement("li");
        newTodo.innerText = val;
        newTodo.classList.add("todoItem");
        todoDiv.appendChild(newTodo);

        // Check Button
        const completeButton = document.createElement('button');
        completeButton.innerHTML = '<i class="fa fa-check"></i>';
        completeButton.classList.add("complete-btn");

        todoDiv.appendChild(completeButton);


        // Trash Button
        const trashButton = document.createElement('button');
        trashButton.innerHTML = '<i class="fa fa-trash"></i>';
        trashButton.classList.add("trash-btn");

        todoDiv.appendChild(trashButton);


        // Append to list
        todoList.appendChild(todoDiv);

        // Clear the input value
        todoInput.value = '';
    }
    
}

// Delete Check
function deleteCheck(e){
    let item = e.target;
    if(item.classList[0] === "trash-btn"){
        const todo = item.parentElement;
        todo.classList.add("fall");
        todo.addEventListener('transitionend', function(){
            todo.remove();
        })
    }

    // Check mark
    if(item.classList[0] === "complete-btn"){
        const todo = item.parentElement;
        todo.classList.toggle("completed");
    }
}


// Filter todos
function filterTodo(e){
    const todos = todoList.childNodes;
    console.log(todos);
    todos.forEach(function(todo){
        switch(e.target.value){
            case "all":
                todo.style.display = "flex";
                break;
            case "completed":
                if(todo.classList.contains("completed")){
                    todo.style.display = "flex";
                }else{
                    todo.style.display = "none";
                }
        }
    });
}