// variables
let imgContainer = document.querySelector('.gallery');

// Functions
let fetchData = () => {
    fetch(`https://jsonplaceholder.typicode.com/posts`)
    .then((response) => {
        return response.json();
    })
    .then((data) => {
        data.map((imgData) => {
            key = imgData.id;
            let img = document.createElement('img');
            img.className = 'gal';
            img.src =  `https://picsum.photos/300/400?random=${key}`;
            imgContainer.appendChild(img);
        })
    })
}

// Calling Function
fetchData();
